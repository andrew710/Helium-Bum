﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Add_Helium : MonoBehaviour {

    public Text helium_text;
	// Use this for initialization
	void Start () {
        //helium_text.text = "helium: " + Balloon_Script.helium;
	}
	
	// Update is called once per frame
	void Update () {

	}
}
